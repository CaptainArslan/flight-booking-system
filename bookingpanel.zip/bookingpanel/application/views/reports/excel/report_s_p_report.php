<?php 
	header("Content-type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=sale_purchase.xls");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		body {
			margin-left: 0px;
			margin-top: 0px;
			margin-right: 0px;
			margin-bottom: 0px;
		}
		body,td,th {
			font-family: "Calibri", Arial, Helvetica, sans-serif;
		}
	</style>
</head>
<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tbody>
			<tr>
				<td>&nbsp;</td>
				<td>
					<table cellspacing="0" cellpadding="0" width="95%" align="center" border="0">
						<tbody>
							<tr>
								<td colspan="3">&nbsp;</td>
							</tr>
							<tr>
								<td width="70%" style="font-weight: bold;font-size: 20px;" align="left">
									Sale Purchase Sheet
								</td>
								<td width="30%" colspan="2" style="font-weight: bold;font-size: 20px;" align="right">
									<?php 
				                        echo($this->session->userdata('user_brand')=='All')?"":$this->session->userdata('user_brand');
				                    ?>
								</td>
							</tr>
							<tr>
								<td colspan="3">&nbsp;</td>
							</tr>
							<tr>
								<td width="70%">
									<strong>From : </strong><?php echo date("d-M-Y",strtotime($start_date)); ?>&nbsp;&nbsp;&nbsp;<strong>To : </strong><?php echo date("d-M-Y",strtotime($end_date)); ?>
								</td>
								<td colspan="2"><?php echo date("d-M-Y") ;?></td>
							</tr>
							<tr>
								<td width="70%">
									<strong>Agent : </strong><?php echo $agent; ?>
								</td>
								<td colspan="2">&nbsp;</td>
							</tr>
							<tr>
								<td width="70%">
									<strong>Brand : </strong><?php echo $brand; ?>
								</td>
								<td colspan="2">&nbsp;</td>
							</tr>
							<tr>
								<td width="70%">
									<strong>Supplier : </strong><?php echo $supplier; ?>
								</td>
								<td colspan="2">&nbsp;</td>
							</tr>
							<tr>
								<td colspan="3" style="font-size: 16px;"><strong>Issued Bookings</strong></td>
							</tr>
							<tr>
								<td colspan="3">
									<table cellspacing="0" cellpadding="0" width="100%" style="border: this solid #000;">
										<thead>
											<tr>
							                    <th width="03%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Sr.<br>No.</th>
							                    <th width="08%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Issue<br>Date</th>
							                    <th width="07%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Agent<br>Name</th>
							                    <th width="07%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Booking<br>Ref No.</th>
							                    <th width="10%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Supplier<br>Ref No.</th>
							                    <th width="15%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Customer Name</th>
							                    <th width="07%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Trans<br>Sale</th>
							                    <th width="07%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Bkg<br>Sale</th>
							                    <th width="07%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Trans<br>Cost</th>
							                    <th align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" colspan="3">Cost</th>
							                    <th width="08%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb" rowspan="2">Profit</th>
							                </tr>
							                <tr>
							                    <th width="07%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb">Bkg Cost</th>
							                    <th width="07%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb">Addi.</th>
							                    <th width="07%" align="center" bgcolor="#039be0" style="color:#ffffff;border: thin solid #bbbbbb">Total</th>
							                </tr>
										</thead>
										<tbody>
							                <?php 
							                    $sr = 1;
							                    $total_bkg_sale = 0;
							                    $total_bkg_cost = 0;
							                    $total_trns_sale = 0;
							                    $total_trns_cost = 0;
							                    $total_add_cost = 0;
							                    $total_cost = 0;
							                    $total_profit_issued = 0;
							                    $issueances = $report_details['issued_booking'];
							                    foreach ($issueances as $key => $issue) {
							                        $trns_sale = GetTransSale($issue['bkg_no']);
							                        $total_trns_sale += $trns_sale;
							                        $trns_cost = GetTransCost($issue['bkg_no']);
							                        $total_trns_cost += $trns_cost;
							                        $bkg_sale = $issue['saleprice'] ;
							                        $total_bkg_sale += $bkg_sale;
							                        $bkg_cost = $issue['bkg_cost'] ;
							                        $total_bkg_cost += $bkg_cost;
							                        $add_cost = $issue['admin_exp'] ;
							                        $total_add_cost += $add_cost;
							                        $cost = $bkg_cost+$add_cost;
							                        $total_cost += $cost;
							                        $profit = $bkg_sale - $cost;
							                        $total_profit_issued += $profit;
							                ?>
							                <tr bgcolor="#fff">
							                    <td width="03%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;"><?php echo $sr; ?></td>
							                    <td width="08%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;"><?php echo date('d-M-y',strtotime($issue['clr_date'])) ;?></td>
							                    <td width="07%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;"><?php remove_space($issue['bkg_agent']); ?></td>
							                    <td width="07%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;">
							                        <a class="font-weight-bold text-blue" href="<?php echo base_url("booking/issued/".hashing($issue['bkg_no'])) ?>"><?php echo $issue['bkg_no']; ?></a>
							                    </td>
							                    <td width="10%"align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;"><?php custom_echo($issue['bkg_supplier_reference'],15) ; ?></td>
							                    <td width="15%" align="left" style="border-bottom: thin solid #bbbbbb;font-size: 15px;"><?php custom_echo($issue['cst_name'],25) ; ?></td>
							                    <td width="07%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;" bgcolor="#<?php echo($trns_sale!=$bkg_sale)?"f8dde0":"fff"; ?>">
							                        <?php echo number_format($trns_sale,2) ; ?>
							                    </td>
							                    <td width="07%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;" bgcolor="#<?php echo($trns_sale!=$bkg_sale)?"f8dde0":"fff"; ?>">
							                        <?php echo number_format($bkg_sale,2) ; ?>
							                    </td>
							                    <td width="07%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;" bgcolor="#<?php echo($trns_cost!=$bkg_cost)?"f8dde0":"fff"; ?>">
							                        <?php echo number_format($trns_cost,2) ; ?>
							                    </td>
							                    <td width="08%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;" bgcolor="#<?php echo($trns_cost!=$bkg_cost)?"f8dde0":"fff"; ?>">
							                        <?php echo number_format($bkg_cost,2) ; ?>
							                    </td>
							                    <td width="07%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;"><?php echo number_format($add_cost,2) ; ?></td>
							                    <td width="07%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;"><?php echo number_format($cost,2) ; ?></td>
							                    <td width="07%" align="center" style="border-bottom: thin solid #bbbbbb;font-size: 15px;"><?php echo number_format($profit,2) ; ?></td>
							                </tr>
							                <?php 
							                    $sr++;
							                    }
							                ?>
							            </tbody>
							            <tfoot>
							            	<tr bgcolor="#fff">
							                    <th align="right" style="font-size:14px;border: thin solid #bbbbbb;" bgcolor="#f5f5f5" colspan="6">Total</th>
							                    <th align="center" style="font-size:14px;border: thin solid #bbbbbb;" bgcolor="#f5f5f5"><?php echo number_format($total_trns_sale) ; ?></th>
							                    <th align="center" style="font-size:14px;border: thin solid #bbbbbb;" bgcolor="#f5f5f5"><?php echo number_format($total_bkg_sale,2) ; ?></th>
							                    <th align="center" style="font-size:14px;border: thin solid #bbbbbb;" bgcolor="#f5f5f5"><?php echo number_format($total_trns_cost,2) ; ?></th>
							                    <th align="center" style="font-size:14px;border: thin solid #bbbbbb;" bgcolor="#f5f5f5"><?php echo number_format($total_bkg_cost,2) ; ?></th>
							                    <th align="center" style="font-size:14px;border: thin solid #bbbbbb;" bgcolor="#f5f5f5"><?php echo number_format($total_add_cost,2) ; ?></th>
							                    <th align="center" style="font-size:14px;border: thin solid #bbbbbb;" bgcolor="#f5f5f5"><?php echo number_format($total_cost,2) ; ?></th>
							                    <th align="center" style="font-size:14px;border: thin solid #bbbbbb;" bgcolor="#f5f5f5"><?php echo number_format($total_profit_issued,2) ; ?></th>
							                </tr>
							            </tfoot>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>&nbsp;</td>
			</tr>
		</tbody>
	</table>
</body>
</html>