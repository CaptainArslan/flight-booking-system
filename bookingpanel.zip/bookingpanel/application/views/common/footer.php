<footer class="footer footer-transparent">
    <div class="container">
        <div class="row text-center align-items-center flex-row-reverse">
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
            Copyright © <?php echo date('Y') ; ?>
            <a href="javascript:void(0);" class="link-secondary">Vision Technologies</a>.
            All rights reserved.
            </div>
        </div>
    </div>
</footer>